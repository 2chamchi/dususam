
    @ApiOperation(httpMethod = "POST", value = "상황 등록")
    @ApiImplicitParams({
            @ApiImplicitParam(name="mediaDeviceId", dataType = "String"),
            @ApiImplicitParam(name="title", dataType = "String"),
            @ApiImplicitParam(name="content", dataType = "String"),
            @ApiImplicitParam(name="ratingId", dataType = "String"),
            @ApiImplicitParam(name="carSearchTxt", dataType = "String"),
            @ApiImplicitParam(name="searchResult", dataType = "String"),
            @ApiImplicitParam(name="fileList", dataType = "File"),
            @ApiImplicitParam(name="fileList", dataType = "File"),
            @ApiImplicitParam(name="fileList", dataType = "File"),
            @ApiImplicitParam(name="fileList", dataType = "File")
    })
    @RequestMapping(
            value = "/{incidentType}",
            method = {RequestMethod.POST},
            consumes = {"multipart/form-data"},
            produces = "application/json; charset=UTF-8")
    public String addIncidentForm(
            MultipartHttpServletRequest request,
            @RequestHeader(value = "token", required = TOKEN_YN) String token,
            @PathVariable(value = "incidentType") String incident, // 상황 유형 (의심상황, 경고상황, 비상벨)
            @RequestParam("mediaDeviceId") String mediaDeviceId,
            @RequestParam("title") String title,
            @RequestParam("content") String content,
            @RequestParam("ratingId") String ratingId,
            @RequestParam("carSearchTxt") String carSearchTxt,
            @RequestParam("searchResult") String searchResult,
            @RequestPart("fileList") List<MultipartFile> fileList){

        if(fileList == null || fileList.isEmpty()){
            return JsonUtils.apiResponseResult(
                    HttpServletResponse.SC_NOT_FOUND,
                    CommonConstant.FAIL_LOWCASE);
        }

        String loginId = "";
        IncidentMngt incidentMngt;
        String date = "";
        int incidentType = Integer.parseInt(incident);
        String result;
        if(!Strings.isNullOrEmpty(token)){
            Map<String, Object> userInfo = apiCommonService.getUserInfo(token);
            if (userInfo.isEmpty()) {
                logger.debug("Invalid token : {}", token);
                return JsonUtils.apiResponseResult(HttpServletResponse.SC_BAD_REQUEST, "Invalid token", token);
            }
            loginId = (String) userInfo.get("loginId");
        }

        try {
            date = DateTimeUtil.toFormatedTimeString(Calendar.getInstance(), date14);
            incidentMngt.setIncidentRegisterDate(date);
        } catch (DateTimeUtilException e) {
            logger.error(e.getMessage(), e);
        }

        logger.info("addIncident incidentVO: {}", incidentMngt);

        result =  apiIncidentsService.addIncident(incidentType, incidentMngt, fileList);
        return result;
    }

	@SuppressWarnings({ "unchecked", "static-access" })
	public List<WorkFormatMngt> selectTotalWorkForamtionMngtList(Map<String, Object> paramMap) {
		List<WorkFormatMngt> list = null;
		Session session = null;
		try {
			String workStartDate = (String) paramMap.get("workStartDate");
			
			int startNum = Integer.parseInt(paramMap.get("startNum").toString());
			int endNum = Integer.parseInt(paramMap.get("endNum").toString());

			session = getSessionFactory().openSession();

			Criteria criteria = session.createCriteria(WorkFormatMngt.class);

			if (startNum == 0) {
				criteria.setFirstResult(startNum);
			} else {
				criteria.setFirstResult(startNum - 1);
			}
			criteria.setMaxResults(endNum);

			if (workStartDate != null) {
				criteria.add(Restrictions.eq("workStartDate", workStartDate));
			}
			criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			list = criteria.list();
		} catch (HibernateException e) {
			LOGGER.error("WorkFormatMngtDao selectTotalWorkForamtionMngtList", e);
		} finally {
			HibernateUtils.closeSession(session);
		}
		return list;
	}
	
	public List<IncidentMngt> getIncidentMngtList(Map<String, Object> paramMap) {
        List<IncidentMngt> list = null;
        Session session = null;

        try {
            String searchDate = (String) paramMap.get("searchDate");
            String user = (String) paramMap.get("user");

            int startNum = Integer.parseInt(paramMap.get(CommonConstant.START_NUM).toString());
            int endNum = Integer.parseInt(paramMap.get(CommonConstant.END_NUM).toString());

            session = getSessionFactory().openSession();
            Criteria criteria = session.createCriteria(IncidentMngt.class);

            if (startNum == 0) {
                criteria.setFirstResult(startNum);
            } else {
                criteria.setFirstResult(startNum - 1);
            }

            criteria.setMaxResults(endNum);
            if (!Strings.isNullOrEmpty(searchDate)) {
                criteria.add(Restrictions.like("incidentRegisterDate", searchDate + "%"));
            }
            if (!Strings.isNullOrEmpty(user)) {
                criteria.add(Restrictions.like("incidentRegisterUserId", "%" + user + "%"));
            }

            criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

            list = criteria.list();

        } catch (HibernateException e) {
            LOGGER.error("getIncidentMngtList SQL ERROR", e.getMessage());
        } finally {
            HibernateUtils.closeSession(session);
        }
        return list;
    }
	
	public List<String> saveThumbnails(String incidentId, List<MultipartFile> fileList){
        List<String> fileNameList = Lists.newArrayList();
        StringBuilder path;
        File f;
        String reqFileName;
        String fileName;
        String regexFileFormat = "\\.(png|jpg|jpeg|PNG|JPG|JPEG)$";
        for(MultipartFile mf: fileList){
            reqFileName = mf.getOriginalFilename().split(regexFileFormat)[0];
            fileName = incidentId + "_" + reqFileName + ".png";
            path = new StringBuilder();
            path
                    .append(eventImagePath)
                    .append(File.separator)
                    .append(fileName);
            logger.info("saveThumbnails.path : {}", path);
            f = new File(path.toString());
            try{
                mf.transferTo(f);
                fileNameList.add(fileName);
            }catch (IOException e){
                logger.error("saveThumbnails : {}", e.getMessage());
                fileNameList.clear();
                break;
            }
        }

        return fileNameList;
    }
	
	@Bean
	public PropertyPlaceholderConfigurer confFileInfo(){
		PropertyPlaceholderConfigurer conf = new ConfFileInfo();
		//conf.setLocation( new ClassPathResource("config.properties") );
		conf.setLocation( new FileSystemResource( SystemProperties.getProperty("VMS_HOME") + File.separator + "config.properties" ) );
		return conf;
	}
	
registry.addResourceHandler("/eventPicture/**").addResourceLocations("file:" + File.separator + File.separator
				+ File.separator + ConfFileInfo.get("event.picture") + File.separator)
				.setCachePeriod(0);
	
	@Bean
	public Filter characterEncodingFilter() {
		CharacterEncodingFilter characterEncodingFilter = new CharacterEncodingFilter();
		characterEncodingFilter.setEncoding("UTF-8");
		characterEncodingFilter.setForceEncoding(true);
		return characterEncodingFilter;
	}

	@Bean(name = "multipartResolver")
	public MultipartResolver multipartResolver() {
		// 스프링 4버전 부터는 StandardServletMultipartResolver 를 사용,
		StandardServletMultipartResolver multipartResolver = new StandardServletMultipartResolver();
		return multipartResolver;
	}
	
	
	@Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws HttpException, IOException {
        try {

            HttpSession session = request.getSession();
            String requestUri = request.getRequestURI();

            if(requestUri.contains("rest-apis") ||
                requestUri.contains("swagger") ||
                requestUri.contains("api-docs") ||
                requestUri.contains("widget")){

                return true;
            }


            if (session == null) {
  
            }
            
            if(requestUri.contains() || // 운영 관리 진입 페이지
              
               
			) {
                return true;
            } else {
                
            return true;
        }catch (NullPointerException | IllegalAccessException e){
        	response.sendRedirect("errorPage");
            return false;
        }
    }
	
	
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(new VmsInterceptor());
		registry.addInterceptor(localeChangeInterCeptor());
	}
	
	@ControllerAdvice
public class ExceptionController {
	
	private static final Logger logger = LoggerManager.getLogger(ExceptionController.class);
	
	@ResponseBody
	@ExceptionHandler(Exception.class)
	public JSONObject exception(Exception ex) {
		JSONObject exceptionObject = new JSONObject();
		exceptionObject.put("errMsg", ex.getMessage());
		
		logger.error("errMsg", ex);
		
		return exceptionObject;
	}
}