/**
 * 실시간 영상 검색 페이지(liveStream/live/liveStreamMain.jsp)에서
 * 사용하는 Layout 관련 api client 객체
 */
(function(View){
    (function (main) {
        var api = function(){
            var that = this;

            var ajaxClient;

            var offset = location.href.indexOf(location.host) + location.host.length;
            that.ctx = location.href.substring(offset,location.href.indexOf('/',offset+1));
            that.url = that.ctx + '/api/v1/';

            that.init = function(){
                ajaxClient = new DudusamClient();
            };

            that.addMember = function(_param, _callback){
                ajaxClient.post({
                    url : that.url,
                    contentType : 'application/json; charset=utf-8',
                    async : false,
                    headers : {
                        token : userToken
                    },
                    data : JSON.stringify(_param), // @RequestBody로 받기 위해 문자열처리
                    success : function(_data){
                        _callback(_data);
                    },
                    fail : function(err){
                        console.log('View.layout.manager', err);
                    }
                });
            };

            that.getMembers = function(_callback){
                ajaxClient.get({
                    url : that.url,
                    contentType : 'application/json; charset=utf-8',
                    headers : {
                        token : userToken
                    },
                    async : false,
                    success : function(_data){
                        _callback(_data);
                    },
                    fail : function(err){
                        console.log('View.layout.api', err);
                    }
                });
            };

            that.getMember = function(_callback){
                ajaxClient.get({
                    url : that.url,
                    contentType : 'application/json; charset=utf-8',
                    headers : {
                        token : userToken
                    },
                    async : false,
                    success : function(_data){
                        _callback(_data);
                    },
                    fail : function(err){
                        console.log('View.layout.api', err);
                    }
                });
            };

            that.updateMember = function(_param, _callback){
                ajaxClient.get({
                    url : that.url + '/' + _param.layoutWebId,
                    contentType : 'application/json; charset=utf-8',
                    headers : {
                        token : userToken
                    },
                    async : false,
                    data : _param,
                    success : function(_data){
                        _callback(_data);
                    },
                    fail : function(err){
                        console.log('View.layout.manager', err);
                    }
                });
            };

            that.deleteMember = function(_param, _callback){
                ajaxClient.put({
                    url : that.url + '/' + _param.layoutWebId,
                    contentType : 'application/json; charset=utf-8',
                    headers : {
                        token : userToken
                    },
                    async : false,
                    data : JSON.stringify(_param),
                    success : function(_data){
                        _callback(_data);
                    },
                    fail : function(err){
                        console.log('View.layout.api', err);
                    }
                });
            };

            that.deleteLayout = function(_param, _callback){
                ajaxClient.delete({
                    url : that.url + '/' + _param.layoutWebId,
                    contentType : 'application/json; charset=utf-8',
                    headers : {
                        token : userToken
                    },
                    async : false,
                    data : _param,
                    success : function(_data){
                        _callback(_data);
                    },
                    fail : function(err){
                        console.log('View.layout.manager', err);
                    }
                });
            };

        };
        main.api = new api();
    })(View.main || (View.main = {}));
})(View || (View = {}));