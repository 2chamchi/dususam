(function(){
    var ConsoleColor, DudusamClient, ApiUrl;

    ConsoleColor = {
        green : 'background: green; color: white; display: block;',
        red : 'background: red; color: white; display: block;'
    };

    ApiUrl = {
        members : {
            add : ''
        },
        groups : {

        },
        preferenceCategory : {

        },
        preferenceItem : {

        },
        preferencePriority : {

        },
        messages : {

        }
    };

    DudusamClient = (function() {
        var that = this;
        var offset;
        var ctx;

        var defaultOption = {
            // contentType : "application/json",
            // dataType : "json",
            // beforeSend : null,
            // complete : null,
            // success : null,
            // error : null
        };

        function DudusamClient(){
            offset = location.href.indexOf(location.host)+location.host.length;
            ctx = location.href.substring(offset,location.href.indexOf('/',offset+1));
        }

        DudusamClient.prototype.get = function(request){
            request.url = encodeURI(request.url);
            var option = {
                beforeSend : that.beforeProcess,
                type : "GET",
                async : false
            };
            $.extend(option, defaultOption, request);
            return $.ajax(option);
        };

        DudusamClient.prototype.post = function (request) {
            request.url = encodeURI(request.url);
            var option = {
                beforeSend : that.beforeProcess,
                type : "POST"
            };
            $.extend(option, defaultOption, request);
            return $.ajax(option);
        };

        DudusamClient.prototype.put = function (request) {
            request.url = encodeURI(request.url);
            var option = {
                beforeSend : that.beforeProcess,
                type : "PUT"
            };
            $.extend(option, defaultOption, request);
            return $.ajax(option);
        };

        DudusamClient.prototype.delete = function (request) {
            //_option.url=_option.url+"?timeStamp="+Number(new Date());
            request.url = encodeURI(request.url);
            var option = {
                beforeSend : that.beforeProcess,
                type : "DELETE"
            };
            $.extend(option, defaultOption, request);
            return $.ajax(option);
        };

        DudusamClient.prototype.beforeProcess = function (request) {
            request.setRequestHeader("requestUrl", window.location.pathname);
        };

        DudusamClient.prototype.abort = function (request) {
            request.abort();
        };

        return DudusamClient;

    })();

}).call(this);